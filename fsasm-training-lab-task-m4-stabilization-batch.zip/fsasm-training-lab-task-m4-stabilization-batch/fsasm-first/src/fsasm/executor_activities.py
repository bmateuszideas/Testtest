"""FS-ASM Executor Activities - activity-based execution with Stub backend for milestone 3 and 4."""

import logging

import mistralai.workflows as workflows
from mistralai.workflows import activity

# Import fsasm modules - these are used in activities, not workflow code
with workflows.workflow.unsafe.imports_passed_through():
    from fsasm.errors import (
        ConfigurationError,
        ProvenanceValidationError,
        ValidationError,
    )
    from fsasm.models import (
        ChildTask,
        ExecutorBackend,
        ExecutorConfig,
        ExecutorOutput,
        EvidenceRecord,
        RunState,
        RunStatus,
        TaskStatus,
        VerificationResult,
        VerificationResultStatus,
    )
    from fsasm.executor import ExecutorStub
    from fsasm.transitions import transition_task
    from fsasm.persistence import RuntimePersistence

logger = logging.getLogger(__name__)


def _validate_finalization_inputs(
    state: RunState,
    task: ChildTask,
    verification_result: VerificationResult,
    evidence_records: list[EvidenceRecord],
) -> None:
    """Validate finalization inputs before any side effect.

    Enforces the F8 finalizer contract: the verification result and evidence
    must belong to the authoritative run and task, the task must be the active
    RUNNING task, and (for a PASS) the checks and evidence must be internally
    consistent. Rejects invalid or contradictory input by raising before any
    task/state mutation or persistence.
    """
    # Identity and execution context.
    if verification_result.run_id != state.run_id:
        raise ValidationError(
            "VerificationResult run_id does not match authoritative RunState",
            field="run_id",
            value=verification_result.run_id,
        )
    if verification_result.task_id != task.task_id:
        raise ValidationError(
            "VerificationResult task_id does not match finalized task",
            field="task_id",
            value=verification_result.task_id,
        )
    if task.status != TaskStatus.RUNNING:
        raise ValidationError(
            "Task must be RUNNING to be finalized",
            field="task.status",
            value=task.status.value,
        )
    if state.active_task_id != task.task_id:
        raise ValidationError(
            "RunState.active_task_id does not identify the finalized task",
            field="active_task_id",
            value=state.active_task_id,
        )
    # Authoritative execution context: the run must be RUNNING, a plan must
    # exist, the supplied task must belong to that plan, and the independently
    # supplied task must agree with the authoritative plan task on execution
    # state (status RUNNING and attempt). The task and plan task are separate
    # objects after the activity serialization boundary, so they are compared
    # by value, not by shared object identity.
    if state.status != RunStatus.RUNNING:
        raise ValidationError(
            "RunState must be RUNNING to finalize a task",
            field="state.status",
            value=state.status.value,
        )
    if state.plan is None:
        raise ValidationError(
            "RunState must have an authoritative plan to finalize a task",
            field="plan",
            value=None,
        )
    plan_task_ids = {t.task_id for t in state.plan.tasks}
    if task.task_id not in plan_task_ids:
        raise ValidationError(
            "Finalized task does not belong to the authoritative plan",
            field="task_id",
            value=task.task_id,
        )
    plan_task = next(t for t in state.plan.tasks if t.task_id == task.task_id)
    if plan_task.status != TaskStatus.RUNNING:
        raise ValidationError(
            "Authoritative plan task must be RUNNING for finalization",
            field="plan_task.status",
            value=plan_task.status.value,
        )
    if plan_task.attempt != task.attempt:
        raise ValidationError(
            "Authoritative plan task attempt disagrees with supplied task attempt",
            field="plan_task.attempt",
            value=plan_task.attempt,
        )

    # Every supplied evidence record must belong to the authoritative run/task.
    for evidence in evidence_records:
        if evidence.run_id != state.run_id:
            raise ValidationError(
                "EvidenceRecord run_id does not match authoritative run",
                field="evidence.run_id",
                value=evidence.run_id,
            )
        if evidence.task_id != task.task_id:
            raise ValidationError(
                "EvidenceRecord task_id does not match finalized task",
                field="evidence.task_id",
                value=evidence.task_id,
            )

    # Internal verification consistency only for PASS.
    if verification_result.status == VerificationResultStatus.PASS:
        checks = verification_result.checks
        if len(checks) == 0:
            raise ValidationError(
                "PASS requires at least one VerificationCheck",
                field="checks",
                value=checks,
            )
        if not all(c.passed for c in checks):
            raise ValidationError(
                "PASS result contains a failed VerificationCheck",
                field="checks",
                value=checks,
            )
        if len(evidence_records) == 0:
            raise ValidationError(
                "PASS requires nonempty task execution evidence",
                field="evidence_records",
                value=evidence_records,
            )


# =============================================================================
# EXECUTOR ACTIVITIES
# =============================================================================


@activity(
    name="fsasm-execute-task",
    retry_policy_max_attempts=1,
)
async def execute_task_activity(
    task: ChildTask,
    run_id: str,
    executor_config: ExecutorConfig,
    attempt: int = 0,
) -> ExecutorOutput:
    """
    Execute a single task using the configured executor backend.

    For M3/M4, only STUB backend is implemented.
    The executor produces ExecutorOutput (a CLAIM/RESULT).

    For M4: The attempt parameter is passed to the stub executor to control
    deterministic failure behavior (stub_fail_first_n_attempts).

    Args:
        task: The ChildTask to execute.
        run_id: The run_id for traceability.
        executor_config: The ExecutorConfig specifying which backend to use.
        attempt: The current attempt number (0-indexed) for M4 deterministic failure.

    Returns:
        ExecutorOutput from the executor.

    Raises:
        ConfigurationError: If backend is not STUB.
    """
    if executor_config.backend != ExecutorBackend.STUB:
        raise ConfigurationError(
            message=f"Milestone 3/4 only supports ExecutorBackend.STUB, got '{executor_config.backend}'",
            backend=executor_config.backend.value,
        )

    # Use the stub executor - pass attempt for M4 deterministic failure
    # Pass stub_fail_first_n_attempts from config to executor
    executor = ExecutorStub(
        stub_fail_first_n_attempts=executor_config.stub_fail_first_n_attempts
    )
    output = await executor.execute_async(task, run_id, attempt)

    return output


@activity(
    name="fsasm-validate-executor-output-provenance",
    retry_policy_max_attempts=1,
)
async def validate_executor_output_provenance_activity(
    executor_output: ExecutorOutput,
    expected_task_id: str,
    expected_run_id: str,
) -> ExecutorOutput:
    """
    Validate ExecutorOutput provenance before converting to EvidenceRecord.

    Checks:
    - executor_output.task_id == expected_task_id
    - executor_output.metadata.task_id == expected_task_id
    - executor_output.metadata.run_id == expected_run_id

    Rejects mismatches. Never relabels mismatched ExecutorOutput as evidence.

    Args:
        executor_output: The ExecutorOutput to validate.
        expected_task_id: The expected task_id from the canonical ChildTask.
        expected_run_id: The expected run_id from the canonical RunState.

    Returns:
        The validated ExecutorOutput (same object).

    Raises:
        ProvenanceValidationError: If any provenance check fails.
    """
    # Check all three provenance requirements
    if executor_output.task_id != expected_task_id:
        raise ProvenanceValidationError(
            message=f"ExecutorOutput task_id mismatch: expected '{expected_task_id}', got '{executor_output.task_id}'",
            expected_task_id=expected_task_id,
            actual_task_id=executor_output.task_id,
            expected_run_id=expected_run_id,
            actual_run_id=executor_output.run_id,
            check_type="output_task_id",
        )

    if executor_output.run_id != expected_run_id:
        raise ProvenanceValidationError(
            message=f"ExecutorOutput run_id mismatch: expected '{expected_run_id}', got '{executor_output.run_id}'",
            expected_task_id=expected_task_id,
            actual_task_id=executor_output.task_id,
            expected_run_id=expected_run_id,
            actual_run_id=executor_output.run_id,
            check_type="output_run_id",
        )

    if executor_output.metadata.task_id != expected_task_id:
        raise ProvenanceValidationError(
            message=f"ExecutorOutput metadata.task_id mismatch: expected '{expected_task_id}', got '{executor_output.metadata.task_id}'",
            expected_task_id=expected_task_id,
            actual_task_id=executor_output.metadata.task_id,
            expected_run_id=expected_run_id,
            actual_run_id=executor_output.metadata.run_id,
            check_type="metadata_task_id",
        )

    if executor_output.metadata.run_id != expected_run_id:
        raise ProvenanceValidationError(
            message=f"ExecutorOutput metadata.run_id mismatch: expected '{expected_run_id}', got '{executor_output.metadata.run_id}'",
            expected_task_id=expected_task_id,
            actual_task_id=executor_output.task_id,
            expected_run_id=expected_run_id,
            actual_run_id=executor_output.metadata.run_id,
            check_type="metadata_run_id",
        )

    return executor_output


@activity(
    name="fsasm-convert-executor-output-to-evidence",
    retry_policy_max_attempts=1,
)
async def convert_executor_output_to_evidence_activity(
    executor_output: ExecutorOutput,
    task: ChildTask,
    evidence_counter: int,
    attempt: int = 0,
) -> list[EvidenceRecord]:
    """
    Convert validated ExecutorOutput to EvidenceRecord(s).

    For deterministic M3/M4 stub execution:
    - If task.expected_evidence is empty, create one fallback evidence record with kind "executor_output"
    - Otherwise, create one EvidenceRecord per declared expected evidence kind

    Uses deterministic safe IDs (ordinal counters) while keeping the original evidence kind as data.
    For M4, includes attempt number in evidence metadata.

    Args:
        executor_output: The validated ExecutorOutput.
        task: The ChildTask being executed.
        evidence_counter: An ordinal counter for generating deterministic evidence IDs.
        attempt: The current attempt number for this execution.

    Returns:
        List of EvidenceRecord instances.
    """
    run_id = executor_output.run_id
    task_id = executor_output.task_id
    evidence_records: list[EvidenceRecord] = []

    if not task.expected_evidence:
        # Fallback: one evidence record with kind "executor_output"
        evidence_id = f"evidence-{run_id}-{task_id}-exec-{evidence_counter:03d}-000"
        evidence_record = EvidenceRecord(
            evidence_id=evidence_id,
            run_id=run_id,
            task_id=task_id,
            kind="executor_output",
            source="executor_stub",
            payload={
                "executor_output": executor_output.model_dump(),
                "original_evidence_kinds": [],
                "attempt": attempt,
            },
        )
        evidence_records.append(evidence_record)
    else:
        # Create one EvidenceRecord per declared expected evidence kind
        for idx, expected_kind in enumerate(task.expected_evidence):
            evidence_id = (
                f"evidence-{run_id}-{task_id}-exec-{evidence_counter:03d}-{idx:03d}"
            )
            evidence_record = EvidenceRecord(
                evidence_id=evidence_id,
                run_id=run_id,
                task_id=task_id,
                kind=expected_kind,
                source="executor_stub",
                payload={
                    "executor_output": executor_output.model_dump(),
                    "original_evidence_kind": expected_kind,
                    "evidence_index": idx,
                    "attempt": attempt,
                },
            )
            evidence_records.append(evidence_record)

    return evidence_records


@activity(
    name="fsasm-verify-task-execution",
    retry_policy_max_attempts=1,
)
async def verify_task_execution_activity(
    run_id: str,
    task: ChildTask,
    evidence_records: list[EvidenceRecord],
) -> VerificationResult:
    """
    Verify task execution using deterministic checks.

    Thin wrapper around domain verifier.VerificationSpec.expected check.

    Verification operates on:
    - authoritative run_id
    - ChildTask
    - list[EvidenceRecord]

    Evidence must match BOTH:
    - evidence.run_id == authoritative run_id
    - evidence.task_id == task.task_id

    Verification requires ALL declared expected evidence kinds to be present.

    Args:
        run_id: The authoritative run_id.
        task: The ChildTask being verified.
        evidence_records: List of EvidenceRecord for this task.

    Returns:
        VerificationResult with PASS or FAIL.
    """
    from fsasm.verifier import DeterministicVerifier

    verifier = DeterministicVerifier()
    return verifier.verify_task_execution(run_id, task, evidence_records)


@activity(
    name="fsasm-prepare-task",
    retry_policy_max_attempts=1,
)
async def prepare_task_activity(
    state: RunState,
    task: ChildTask,
) -> tuple[RunState, ChildTask]:
    """
    Prepare a task for execution.

    BEFORE Executor execution begins, persisted state must already truthfully represent:
    - RunState.status = RUNNING
    - RunState.active_task_id = executed task ID
    - TASK-001.status = RUNNING
    - TASK-002/003 = PENDING

    This must be true in BOTH runtime/.../state.json and runtime/.../plan.json.

    If the workflow crashes immediately after prepare, filesystem state must still be internally consistent.

    Note: transition_task(READY->RUNNING) increments task.attempt by 1.

    Args:
        state: The current RunState.
        task: The ChildTask to prepare.

    Returns:
        Tuple of (updated RunState, updated ChildTask).
    """
    persistence = RuntimePersistence()

    # Transition run to RUNNING (from PLANNED) first
    from fsasm.transitions import transition_run

    if state.status == RunStatus.PLANNED:
        state = transition_run(state, RunStatus.RUNNING)

    # Transition task to RUNNING (this increments attempt counter)
    task = transition_task(task, TaskStatus.RUNNING)

    # Update state
    state.active_task_id = task.task_id
    state.touch()

    # Update plan in state to reflect task status change
    # Replace the task object in the plan rather than just assigning status
    if state.plan is not None:
        plan = state.plan
        updated_tasks = []
        for plan_task in plan.tasks:
            if plan_task.task_id == task.task_id:
                # Replace with the transitioned task
                updated_tasks.append(task)
            else:
                # Keep other tasks as-is
                updated_tasks.append(plan_task)
        plan.tasks = updated_tasks

    # Persist state
    persistence.save_run_state(state)

    # Persist plan
    if state.plan is not None:
        persistence.save_plan(state.plan)

    return state, task


@activity(
    name="fsasm-finalize-task",
    retry_policy_max_attempts=1,
)
async def finalize_task_activity(
    state: RunState,
    task: ChildTask,
    verification_result: VerificationResult,
    evidence_records: list[EvidenceRecord],
) -> tuple[RunState, ChildTask]:
    """
    Finalize a task after execution and verification.

    After FINALIZE, persisted state must truthfully represent:

    PASS path:
    - TASK-001 = PASSED
    - completed_task_ids contains TASK-001
    - failed_task_ids does not
    - active_task_id = None
    - RunState = RUNNING

    FAIL path:
    - TASK-001 = FAILED
    - failed_task_ids contains TASK-001
    - completed_task_ids does not
    - active_task_id = None
    - RunState = RUNNING

    Again, state.plan and persisted plan.json must agree.

    Args:
        state: The current RunState.
        task: The ChildTask that was executed.
        verification_result: The VerificationResult from task verification.
        evidence_records: The EvidenceRecord list for this task.

    Returns:
        Tuple of (updated RunState, updated ChildTask).
    """
    # F8: validate identity, execution context, checks and evidence before any
    # side effect. Invalid or contradictory input fails closed here; no task
    # status mutation, no completed/failed collection mutation, no state or
    # plan overwrite, and no evidence/verification persistence occurs for a
    # rejected call.
    _validate_finalization_inputs(state, task, verification_result, evidence_records)

    persistence = RuntimePersistence()

    # Determine final task status from verification
    if verification_result.status == VerificationResultStatus.PASS:
        task = transition_task(task, TaskStatus.PASSED, verification_pass=True)
        # Only add to completed if not already there (prevent duplicates)
        if task.task_id not in state.completed_task_ids:
            state.completed_task_ids.append(task.task_id)
        # Ensure not in failed
        if task.task_id in state.failed_task_ids:
            state.failed_task_ids.remove(task.task_id)
    else:
        task = transition_task(task, TaskStatus.FAILED, verification_pass=False)
        # Only add to failed if not already there (prevent duplicates)
        if task.task_id not in state.failed_task_ids:
            state.failed_task_ids.append(task.task_id)
        # Ensure not in completed
        if task.task_id in state.completed_task_ids:
            state.completed_task_ids.remove(task.task_id)

    # Clear active task
    state.active_task_id = None

    # RunState remains RUNNING

    # Update plan in state to reflect task status change
    if state.plan is not None:
        plan = state.plan
        for plan_task in plan.tasks:
            if plan_task.task_id == task.task_id:
                plan_task.status = task.status
                plan_task.attempt = task.attempt
            # Other tasks remain in their current status (should be PENDING)

    # Persist evidence records
    for evidence in evidence_records:
        persistence.save_evidence(evidence)

    # Persist verification result
    persistence.save_verification_result(verification_result)

    # Persist state
    state.touch()
    persistence.save_run_state(state)

    # Persist plan
    if state.plan is not None:
        persistence.save_plan(state.plan)

    return state, task
